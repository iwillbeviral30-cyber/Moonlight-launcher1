# Moonlight Launcher

Android landscape launcher starter project. Build using GitHub Actions: open Actions, select Build Moonlight Launcher APK, and run workflow. The APK launches the Minecraft Bedrock app installed on the device; it does not bundle Minecraft. CurseForge and MCDL cards open their websites. Worlds/Packs is a placeholder. Theme colors and slider values are saved, but brightness/transparency are not yet applied globally.
