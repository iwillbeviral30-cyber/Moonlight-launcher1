package com.moonlight.launcher;

import android.app.*;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.view.Gravity;
import android.widget.*;

public class MainActivity extends Activity {
    int bg = Color.rgb(7, 12, 19), panel = Color.rgb(17, 27, 38);
    int accent, brightness = 100, transparency = 100;
    LinearLayout content;
    final int[] colors = {0xFF41FF91,0xFF00E5FF,0xFF448AFF,0xFF7C4DFF,0xFFE040FB,0xFFFF4081,0xFFFF5252,0xFFFF9100,0xFFFFD740,0xFFFFFF00,0xFFB2FF59,0xFF00E676,0xFF64FFDA,0xFF80D8FF,0xFFB388FF,0xFFFFFFFF};

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        accent = getPreferences(0).getInt("accent", colors[0]);
        brightness = getPreferences(0).getInt("brightness", 100);
        transparency = getPreferences(0).getInt("transparency", 100);
        getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg);
        showHome();
    }
    GradientDrawable shape(int color, int stroke) { GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(18); d.setStroke(1,stroke); return d; }
    TextView label(String s,int size) { TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(Color.WHITE); t.setPadding(12,9,12,9); return t; }
    LinearLayout col() { LinearLayout l=new LinearLayout(this); l.setOrientation(1); l.setPadding(8,6,8,6); return l; }
    LinearLayout row() { LinearLayout l=new LinearLayout(this); l.setOrientation(0); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    void setup(String subtitle) {
        LinearLayout root=col(); root.setBackgroundColor(bg);
        TextView brand=label("☾  MOONLIGHT LAUNCHER",22); brand.setTextColor(accent); brand.setTypeface(null,Typeface.BOLD); root.addView(brand);
        root.addView(label(subtitle,17)); ScrollView scroll=new ScrollView(this); content=col(); scroll.addView(content); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
    }
    void card(LinearLayout parent,String title,String desc,Runnable action) {
        LinearLayout c=col(); c.setBackground(shape(panel,accent)); TextView h=label(title,17); h.setTypeface(null,Typeface.BOLD); h.setTextColor(accent); c.addView(h); c.addView(label(desc,12)); c.setOnClickListener(v->action.run()); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1); p.setMargins(4,4,4,4); parent.addView(c,p);
    }
    void button(LinearLayout parent,String s,Runnable r) { Button b=new Button(this); b.setText(s); b.setTextColor(Color.BLACK); b.setBackground(shape(accent,accent)); b.setOnClickListener(v->r.run()); parent.addView(b); }
    void showHome() {
        setup("HOME  /  PLAY BEYOND");
        TextView hero=label("YOUR WORLDS. YOUR MODS. YOUR MOONLIGHT.\nA desktop-style Bedrock launcher for mobile.",19); hero.setBackground(shape(panel,accent)); content.addView(hero);
        button(content,"▶   LAUNCH MINECRAFT",this::launchMinecraft);
        content.addView(label("DISCOVER & MANAGE",14)); LinearLayout r=row();
        card(r,"CurseForge","Browse addons",()->open("https://www.curseforge.com/minecraft-bedrock"));
        card(r,"MCDL","Minecraft downloads",()->open("https://mcdl.org/"));
        card(r,"Worlds & Packs","World and pack library",()->info("Worlds & Packs","File management is not connected yet.")); content.addView(r);
        content.addView(label("QUICK ACCESS",14)); LinearLayout q=row(); card(q,"Theme","16 colors & appearance",this::showTheme); card(q,"Settings","Launcher settings",this::showSettings); content.addView(q);
        LinearLayout q2=row(); card(q2,"About","Version and information",()->info("About Moonlight","Moonlight Launcher\nVersion 1.0")); card(q2,"Logs","Build and app logs",()->info("Logs","No app logs collected.")); content.addView(q2);
        TextView foot=label("●  LAUNCHER READY     •     ANDROID",12); foot.setTextColor(accent); content.addView(foot);
    }
    void launchMinecraft() { Intent i=getPackageManager().getLaunchIntentForPackage("com.mojang.minecraftpe"); if(i!=null) startActivity(i); else info("Minecraft not found","Install Minecraft Bedrock on this device first."); }
    void showTheme() {
        setup("THEME & APPEARANCE"); content.addView(label("TEXT / ACCENT COLOR — 16 OPTIONS",14));
        for(int n=0;n<16;n+=4){ LinearLayout r=row(); for(int j=n;j<n+4;j++){ final int c=colors[j]; Button b=new Button(this); b.setText("●"); b.setTextSize(22); b.setTextColor(c); b.setBackground(shape(panel,c)); b.setOnClickListener(v->{accent=c; getPreferences(0).edit().putInt("accent",c).apply(); showTheme();}); r.addView(b,new LinearLayout.LayoutParams(0,54,1)); } content.addView(r); }
        content.addView(label("Brightness: "+brightness+"%",14)); SeekBar bs=new SeekBar(this); bs.setMax(100); bs.setProgress(brightness); bs.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean u){brightness=p;} public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){getPreferences(0).edit().putInt("brightness",brightness).apply(); showTheme();}}); content.addView(bs);
        content.addView(label("Transparency: "+transparency+"%",14)); SeekBar ts=new SeekBar(this); ts.setMax(100); ts.setProgress(transparency); ts.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean u){transparency=p;} public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){getPreferences(0).edit().putInt("transparency",transparency).apply(); showTheme();}}); content.addView(ts);
        button(content,"←  BACK HOME",this::showHome);
    }
    void showSettings(){ setup("SETTINGS"); content.addView(label("Minecraft package: com.mojang.minecraftpe",14)); content.addView(label("Layout: Landscape dashboard",14)); button(content,"Theme & Appearance",this::showTheme); button(content,"About Moonlight",()->info("About","Moonlight Launcher v1.0")); button(content,"Back Home",this::showHome); }
    void open(String url){try{startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));}catch(Exception e){info("Cannot open link",url);}}
    void info(String title,String msg){new AlertDialog.Builder(this).setTitle(title).setMessage(msg).setPositiveButton("OK",null).show();}
    @Override public void onBackPressed(){showHome();}
}
